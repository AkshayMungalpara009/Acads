#include<stdio.h>
int main(void)
{
  int i,j,n,a[500][500],flag=0;
  printf("Enter the order of a square matrix :");
  scanf("%d",&n);
  for(i=0 ; i<n ; i++)
  {
   for(j=0 ; j<n ; j++)
   {
    printf("Enter the number a[%d][%d] :",i+1,j+1);
    scanf("%d",&a[i][j]);
   }
  }

  for(i=1 ; i<n ; i++)
  {
   for(j=0 ; j<i ; j++)
   {
     if(a[i][j]!=0)
       flag=1;
   }
   }

   if(flag==0)
    printf("your matix is upper triangular matrix.\n");
    else
    printf("your matix is  not upper triangular matrix.\n");
  
}
