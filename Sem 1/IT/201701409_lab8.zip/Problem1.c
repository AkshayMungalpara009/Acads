#include<stdio.h>
#include<string.h>
int main(void)
{
   char a[500];
   int i,b[500],l;
   printf("Enter the string :");
   scanf("%s",a);
   l=strlen(a);
   for(i=0 ; i<l ; i++)
   {
     b[i]=a[i];
   }
   for(i=0 ; i<l ;i++)
   {
   if(b[i]>=65 && b[i]<=90)
   {
     b[i]=b[i]+32;
   }
   }
     for(i=0 ; i<l ; i++)
     a[i]=b[i];

     for(i=0 ; i<l ;i++)
       printf("%c",b[i]);   
}
