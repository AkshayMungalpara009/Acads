#include<stdio.h>
#include<string.h>
int main(void)
{
  char a[500],b[500];
  int i,j,k,c[500],d[500],count,flag=0,l1,l2;
  printf("Enter the first string : ");
  //scanf("%s",a);
gets(a);
  printf("Enter the second string : ");
  //scanf("%s",b);
gets(b);
  l1=strlen(a);
  l2=strlen(b);

  for(i=0 ; i<l1 ; i++)
    c[i]=a[i];
    
  for(i=0 ; i<l2 ; i++)
    d[i]=b[i];
    
  for(i=0 ; i<l1 ; i++)
  {
     for(j=0 ; j<l2 ; j++)
     {
       if(c[i]==d[j])
         {
           i=i+1;
         }
      else if(c[i]>d[j])
      {
       printf("1\n");
       flag=2;
       break;
       }       
       else
       {
       printf("-1\n");
       flag=3;
       break;
       }
     }
    break;
  }
  if(flag==0)
  printf("0\n"); 
}
